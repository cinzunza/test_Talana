from dataclasses import dataclass, field



@dataclass
class Jugador:

    name: str
    # movimientos: list[str] = field(default_factory=list)
    # golpes: list[str] = field(default_factory=list)
    mi_turno: list[str] = field(default_factory=list)
    energia: int = 6

    def __str__(self):
        return f"{self.name} : {self.movimientos}"
    

    def asigna_turno(self, jugada: str, jugador: str):
        p = jugada
        if(p == "DSDP" or p == "SAK"):
            return 3
        elif(p == "SDK" or p == "ASAP"):
            return 2
        elif(p == "P" or p == "K"):
            return 1
        else:
            print(f"Ingrese un valor aceptado para {jugador}")
            return 0


    
    def quien_parte(self, name):
        self.name = name
        print(f"Ingrese Movimiento Inicial para {self.name}")
        for i in range(0,1):
            self.mi_turno.append(str(input()))
        print(f"{self.name} Tu jugada vale: {self.mi_turno}")

        return self.mi_turno[0]
