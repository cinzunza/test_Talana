from dataclasses import dataclass, field
from typing import List
import json
import copy
import sys
import itertools

from jugador import Jugador

@dataclass
class RunGame():


    movimientos1: list[str] = field(default_factory=list)
    movimientos2: list[str] = field(default_factory=list)
    movimientos: list[str] = field(default_factory=list)
    golpes: list[str] = field(default_factory=list)
    golpes1: list[str] = field(default_factory=list)
    golpes2: list[str] = field(default_factory=list)    


    def operacion(self, name):
        '''
        Ejemplo de movimientos y golpes
        mov = ["D","DSD","S","DSD","SD"]
        golpes = ["K","P","","K","P"]

        mov = ["SA","SA","SA","ASA","SA"]
        golpes = ["K","","K","P","P"]
        '''


        if name == "Tony":
            print(f"Ingrese Movimientos para {name}")
            for i in range(0,5):
                self.movimientos1.append(str(input())) 
            print(f"Indique Golpes para {name}")
            for i in range(0,5):
                self.golpes1.append(str(input()))
            return self.movimientos1, self.golpes1
        else:
            print(f"Ingrese Movimientos para {name}")
            for i in range(0,5):
                self.movimientos2.append(str(input())) 
            print(f"Indique Golpes para {name}")
            for i in range(0,5):
                self.golpes2.append(str(input()))
            return self.movimientos2, self.golpes2


def main():

    jugador1 = Jugador("Tony")
    xm1 = copy.deepcopy(jugador1)
    jugador2 = Jugador("Arnaldor")
    xm2 = copy.deepcopy(jugador2)
    rungame = RunGame()

    jugada_ini_1 = jugador1.quien_parte(jugador1.name)
    jugada_ini_2 = jugador2.quien_parte(jugador2.name)
    print(f" Jugada: {jugada_ini_1}")

    turno1 = jugador1.asigna_turno(jugada_ini_1,jugador1.name)
    print(turno1)
    turno2 = jugador2.asigna_turno(jugada_ini_2,jugador2.name)
    print(turno2)

    if(turno1 == 0 or turno2 == 0):
        sys.exit()

    if turno1 <= turno2:
        xm1.movimientos, xm1.golpes = rungame.operacion(jugador1.name)
        xm2.movimientos, xm2.golpes = rungame.operacion(jugador2.name)
    else:
        xm1.movimientos, xm1.golpes = rungame.operacion(jugador2.name)
        xm2.movimientos, xm2.golpes = rungame.operacion(jugador1.name)

        
    movs = {"W": "Arriba",
            "S": "Abajo",
            "A": "Izquierda",
            "D": "Derecha"}
        
    golpes = {"P": "Punio",
              "K": "Patada"}

    comb = {"DSDP": 3,
            "SAK": 3,
            "SDK": 2,
            "ASAP": 2,
            "P": 1,
            "K": 1}

    nom_mov = {"DSDP": "Taladoken",
               "SDK": "Remuyuken",
               "SAK": "Remuyuken",
               "ASAP": "Taladoken",
               "P": "Punio",
               "K": "Patada",
               "D": "Avanza",
               "A": "Avanza"}

    mov_Tony = ["DSD","SD", "D"]
    mov_Arnaldor = ["SA","ASA", "A"]

    L = [{"player1":
          {"movimientos": xm1.movimientos,
           "golpes": xm1.golpes},
          "player2":
          {"movimientos": xm2.movimientos,
           "golpes": xm2.golpes}}]

    s = json.dumps(L)
    print(s)

    def get_ataque(m,g):
        test = m+g

        for key, value in nom_mov.items():
            if key == test:
                return value
            else:
                return ""
            
        
    
    movs = list(itertools.chain(*zip(xm1.movimientos, xm2.movimientos)))
    golpes = list(itertools.chain(*zip(xm1.golpes, xm2.golpes)))

    for m,g in zip(movs,golpes):
        name = list(filter(lambda x: m in x, mov_Tony))
        # nom_mov = get_ataque(m,g)
        # nom_mov = dict(filter(lambda x: m+g==x, nom_mov.items()))
        if len(name) != 0:
            name = "Tony"
        else:
            name = "Arnold"
        print(f"{name} {m} y da un {g}")
        

if __name__ == "__main__":
    main()
